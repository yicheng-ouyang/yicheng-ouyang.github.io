package cotrollers;


/**
 * a interface for query
 * 
 * <p>some class implements it should provide several methods to query</p>
 * 
 * @author Huang Yu'an
 */
public interface Query {
	
}
